#include "TargetGenerator.hpp"

TargetGenerator::TargetGenerator()
{

}

TargetGenerator::~TargetGenerator()
{

}

void TargetGenerator::learnTargetType(ATarget *spell)
{
    if (spell)
    {
        if (bookT.find(spell->getType()) != bookT.end())
            return;
        bookT[spell->getType()] = spell->clone();
    }
}

void TargetGenerator::forgetTargetType(std::string const &spellName)
{
    std::map<std::string, ATarget *>::iterator it = bookT.find(spellName);
    if (it != bookT.end())
    {
        delete it->second;
        bookT.erase(it);
    }
}

ATarget *TargetGenerator::createTarget(std::string const &spellName)
{
    ATarget *spell = NULL;
    if (bookT.find(spellName) != bookT.end())
    {
        spell = bookT[spellName];
    }
    return (spell);
}