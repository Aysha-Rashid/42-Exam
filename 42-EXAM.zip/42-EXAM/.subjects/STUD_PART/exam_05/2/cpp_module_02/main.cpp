#include "Warlock.hpp"
#include "ASpell.hpp"
#include "ATarget.hpp"
#include "Fwoosh.hpp"
#include "Fireball.hpp"
#include "Polymorph.hpp"
#include "Dummy.hpp"
#include "BrickWall.hpp"
#include "SpellBook.hpp"
#include "TargetGenerator.hpp"
#include <iostream>

int main() {
    Warlock richard("Richard", "foo");
    richard.introduce();
    richard.setTitle("Hello, I'm Richard the Warlock!");
    richard.introduce();

    Fwoosh* fwoosh = new Fwoosh();
    Fireball* fireball = new Fireball();
    Polymorph* polymorph = new Polymorph();

    richard.learnSpell(fwoosh);
    richard.learnSpell(fireball);
    richard.learnSpell(polymorph);

    richard.forgetSpell("Fwoosh");
    richard.forgetSpell("Unknown");

    TargetGenerator tarGen;
    BrickWall model1;
    Dummy dummy;

    tarGen.learnTargetType(&model1);
    tarGen.learnTargetType(&dummy);
    tarGen.forgetTargetType("Target Practice Dummy");
    tarGen.forgetTargetType("Unknown Type");

    ATarget* wall = tarGen.createTarget("Inconspicuous Red-brick Wall");
    richard.launchSpell("Polymorph", *wall);
    richard.launchSpell("Fireball", *wall); 

    richard.launchSpell("Thunderbolt", *wall);
    delete fwoosh;
    delete fireball;
    delete polymorph;
    delete wall;
    return 0;
}
