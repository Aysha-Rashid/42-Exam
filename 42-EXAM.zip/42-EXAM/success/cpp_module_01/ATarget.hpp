#pragma once
#include <iostream>

#include "ASpell.hpp"
class ASpell;
class ATarget
{
    protected:
        std::string type;
    public:
        std::string const &getType() const;
        ATarget(std::string const &copy);
        ATarget(ATarget const &copy);
        ATarget &operator=(ATarget const &copy);
        ATarget();
        virtual ~ATarget();
        virtual ATarget *clone() const = 0;
        void getHitBySpell(ASpell const &spell) const;
};