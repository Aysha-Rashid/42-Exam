#include "SpellBook.hpp"

SpellBook::SpellBook()
{

}

SpellBook::~SpellBook()
{

}

void SpellBook::learnSpell(ASpell *spell)
{
    if (spell)
    {
        if (book.find(spell->getName()) != book.end())
            return;
        book[spell->getName()] = spell->clone();
    }
}

void SpellBook::forgetSpell(std::string const &spellName)
{
    std::map<std::string, ASpell *>::iterator it = book.find(spellName);
    if (it != book.end())
    {
        delete it->second;
        book.erase(it);
    }
}

ASpell *SpellBook::createSpell(std::string const &spellName)
{
    ASpell *spell = NULL;
    if (book.find(spellName) != book.end())
    {
        spell = book[spellName];
    }
    // return 
    return (spell);
}