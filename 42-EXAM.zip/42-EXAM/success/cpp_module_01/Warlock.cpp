#include "Warlock.hpp"

Warlock::Warlock(std::string const &name, std::string const &title) : name(name), title(title)
{
    std::cout << this->name << ": This looks like another boring day.\n";
}

Warlock::~Warlock()
{
    std::cout << this->name << ": My job here is done!\n";
}

std::string const &Warlock::getName() const
{
    return (this->name);
}

std::string const &Warlock::getTitle() const
{
    return (this->title);
}

void Warlock::setTitle(std::string const &title)
{
    this->title = title;
}

void Warlock::introduce() const
{
    std::cout << this->name << ": I am " << this->name << ", " << this->title << "!\n";
}

void Warlock::learnSpell(ASpell *spell)
{
    if (spell)
    {
        if (book.find(spell->getName()) != book.end())
            return;
        book[spell->getName()] = spell->clone();
    }
}

void Warlock::forgetSpell(std::string spellName)
{
    std::map<std::string, ASpell *>::iterator it = book.find(spellName);
    if (it != book.end())
    {
        delete it->second;
        book.erase(it);
    }
}

void Warlock::launchSpell(std::string spellName, ATarget const &target)
{
    ASpell *spell = NULL;
    if (book.find(spellName) != book.end())
    {
        spell = book[spellName];
        spell->launch(target);
    }
}