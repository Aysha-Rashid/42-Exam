#include "Warlock.hpp"
#include "ASpell.hpp"
#include "ATarget.hpp"
#include "Fwoosh.hpp"
#include "Dummy.hpp"
#include <iostream>

int main() {
    const Warlock constWarlock("Merlin", "the Wise");
    std::cout << constWarlock.getName() << std::endl; 
    std::cout << constWarlock.getTitle() << std::endl;
    constWarlock.introduce();                        

    const Fwoosh fwoosh;
    std::cout << fwoosh.getName() << std::endl;  
    std::cout << fwoosh.getEffects() << std::endl;

    ASpell* spellClone = fwoosh.clone();
    
    const Dummy dummy;
    std::cout << dummy.getType() << std::endl;
    
    ATarget* targetClone = dummy.clone();
    
    Warlock warlock("Dumbledore", "the Grand");
    Dummy target;
    Fwoosh fwooshSpell;
    
    warlock.learnSpell(&fwooshSpell);
    
    const Dummy constTarget;
    warlock.launchSpell("Fwoosh", constTarget);

    warlock.forgetSpell("Fwoosh");
    warlock.launchSpell("Fwoosh", dummy);

    warlock.learnSpell(&fwooshSpell);
    warlock.launchSpell("Fwoosh", constTarget);

    warlock.forgetSpell("NonExistentSpell");

    warlock.launchSpell("NonExistentSpell", dummy);

    
    delete spellClone;
    delete targetClone;
    std::cout << "✅ All const correctness tests completed!\n";
    return 0;
}
