#pragma once
#include <iostream>

class Warlock
{
    private:
        std::string name;
        std::string title;
    public:
        Warlock(std::string const &name, std::string const &title);
        Warlock(Warlock const &copy);
        Warlock &operator=(Warlock const &copy)
        {
            std::cout << "comes here for assignment\n";
            this->title = copy.title;
            return (*this);
        }
        ~Warlock();
        std::string const &getName() const;
        std::string const &getTitle() const;
        void setTitle(std::string const &title);
        void introduce() const;
};